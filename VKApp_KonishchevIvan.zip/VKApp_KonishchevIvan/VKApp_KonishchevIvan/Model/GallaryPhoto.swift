//
//  GallaryPhoto.swift
//  VKApp_KonishchevIvan
//
//  Created by Ivan Konishchev on 13.03.2022.
//

import UIKit

struct GallaryPhoto {
    let photo: [Int: [UIImage]]
}
