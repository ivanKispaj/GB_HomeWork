//
//  HisFriends.swift
//  VKApp_KonishchevIvan
//
//  Created by Ivan Konishchev on 10.03.2022.
//

import UIKit

struct HisFirends {
    let friendsAvatar: UIImage?
    let friendsName: String
}
