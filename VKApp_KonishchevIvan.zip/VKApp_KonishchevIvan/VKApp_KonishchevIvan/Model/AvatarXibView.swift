//
//  AvatarXibView.swift
//  VKApp_KonishchevIvan
//
//  Created by Ivan Konishchev on 05.03.2022.
//

import UIKit

class AvatarXibView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
