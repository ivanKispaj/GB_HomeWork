//
//  UserDetails.swift
//  VKApp_KonishchevIvan
//
//  Created by Ivan Konishchev on 14.02.2022.
//

import UIKit

struct UserData {
    let username = "Ivan Konishchev"
    let useremail = ""
    let userPassword = ""
}
